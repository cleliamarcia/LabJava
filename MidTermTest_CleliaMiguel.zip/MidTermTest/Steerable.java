package MidTermTest;

public interface Steerable {

    void accelerate();

    void steerLeft();

    void steerRight();

}
